<template>
  <view class="calculator-page fire-page-calculator-index" :style="pageLayoutStyle">
    <AppFeedback :owner-id="feedbackOwnerId" />
    <view class="page-head">
      <button class="back" data-fire-press="true" aria-label="返回" @click="back" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">‹</button>
      <text class="page-title">躺平倒计时</text>
      <button v-if="mode==='goal' && state.goalPlan" class="delete-goal" data-fire-press="true" :disabled="saving" @tap="removeGoal" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">删除目标</button><view v-else class="head-space"></view>
    </view>
    <text class="intro-title">{{ mode === 'fire' ? '计算你的自由日' : '为目标安排资金与时间' }}</text>
    <text class="intro-sub">按你填写的数据测算，修改后可重新计算。</text>
    <view class="mode-tabs" role="tablist">
      <button data-fire-press="true" role="tab" :aria-selected="mode === 'fire'" :class="{ active: mode === 'fire' }" @click="switchMode('fire')" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">FIRE 退休模式</button>
      <button data-fire-press="true" role="tab" :aria-selected="mode === 'goal'" :class="{ active: mode === 'goal' }" @click="switchMode('goal')" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">目标储蓄模式</button>
    </view>
    <text v-if="!configured && mode === 'fire'" class="empty-hint">先填写你的财务数据。没有数据时，不展示自由日或倒计时。</text>

    <view v-show="mode === 'fire'" class="form-panel">
      <view v-for="field in fireFields" :key="field.key" class="form-row">
        <label :for="'fire-' + field.key">{{ field.label }}</label>
        <view class="input-row">
          <input :id="'fire-' + field.key" v-model="fire[field.key]" type="text" :aria-label="field.label + '，' + field.unit" :placeholder="field.placeholder" :adjust-position="true" :cursor-spacing="32" @input="invalidate('fire')" />
          <text class="unit">{{ field.unit }}</text>
        </view>
      </view>
      <text class="formula">FIRE 目标资产 = 退休后每月消费 × 12 ÷ 年度提取率。收益按月复利，每月存入在月末投入。</text>
    </view>

    <view v-show="mode === 'goal'" class="form-panel">
      <view class="form-row">
        <label for="goal-name">目标名称</label>
        <view class="input-row"><input id="goal-name" v-model="goal.name" type="text" aria-label="目标名称" placeholder="例如房子、车子或旅行" maxlength="60" :adjust-position="true" :cursor-spacing="32" @input="invalidate('goal')" /></view>
      </view>
      <view v-for="field in goalFields" :key="field.key" class="form-row">
        <label :for="'goal-' + field.key">{{ field.label }}</label>
        <view class="input-row"><input :id="'goal-' + field.key" v-model="goal[field.key]" type="text" :aria-label="field.label + '，' + field.unit" :placeholder="field.placeholder" :adjust-position="true" :cursor-spacing="32" @input="invalidate('goal')" /><text class="unit">{{ field.unit }}</text></view>
      </view>
      <text class="formula">目标资金单独记录，不修改自由计划资产。期望时间用于计算每月需要存入的金额。</text>
    </view>

    <view v-if="errors.length" class="error-panel" role="alert" aria-live="polite"><text v-for="message in errors" :key="message">{{ message }}</text></view>
    <button class="primary" data-fire-press="true" :disabled="saving" @click="calculate" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{ saving ? '保存中…' : mode === 'fire' ? '计算并保存自由日' : '计算目标日' }}</button>

    <view v-if="saving" class="calculation-loading" role="status" aria-live="polite">
      <view class="loading-spinner"></view>
      <text class="loading-title">正在计算</text>
      <text class="loading-copy">正在整理你的资金计划…</text>
    </view>

    <view v-if="result" class="result-panel">
      <text class="result-label">{{ mode === 'fire' ? '我的自由计划' : goal.name }}</text>
      <template v-if="result.date">
        <view class="countdown-line">
          <view v-for="part in countdownUnits" :key="part.id" class="countdown-unit">
            <AnimatedNumber class="countdown-number" :value="part.value" /><text class="countdown-label">{{ part.label }}</text>
          </view>
        </view>
        <text class="result-sub">剩余 {{ totalDays }} 天 · {{ result.months === 0 ? '已达到目标' : '预计到达 ' + dateText(result.date) }}</text>
      </template>
      <text v-else class="unreachable">当前假设下，100 年内暂未达到目标</text>
      <view class="progress"><view class="progress-fill" :style="{width:result.progress + '%'}"></view></view>
      <view class="result-row"><text>当前进度</text><text>{{ result.progress.toFixed(1) }}%</text></view>
      <view class="result-row"><text>{{ mode === 'fire' ? '当前资产' : '为目标已准备' }}</text><text>{{ money(resultAssets) }} 元</text></view>
      <view class="result-row"><text>{{ mode === 'fire' ? 'FIRE 目标门槛' : '目标金额' }}</text><text>{{ money(result.target) }} 元</text></view>
      <view class="result-row"><text>每月存入</text><text>{{ money(result.monthlySaving) }} 元/月</text></view>
      <template v-if="mode === 'goal'">
        <view class="result-row"><text>期望时间</text><text>{{ calculatedGoal.expectedMonths }} 个月</text></view>
        <view class="result-row"><text>按期达成需要存入</text><text>{{ money(Math.ceil(result.requiredMonthly * 100) / 100) }} 元/月</text></view>
        <view class="result-row"><text>期望日期预计资金</text><text>{{ money(result.projectedAtExpected) }} 元</text></view>
        <text class="result-sub">{{ result.onTime ? '按当前计划可在期望时间内达到' : '当前计划未达到期望时间，请调整存入金额或时间' }}</text>
        <button class="primary" data-fire-press="true" :disabled="saving" @click="publishGoal" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">更新目标到首页</button>
        <text class="formula">仅计算会保存目标草稿；确认更新后，首页才展示这项目标。</text>
      </template>
      <template v-else>
        <button class="secondary" data-fire-press="true" @click="toggleDiagnosis" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{ showDiagnosis ? '收起 AI 解析' : '查看' }} PRO 深度诊断</button>
        <view v-if="showDiagnosis && !isProMember" class="pro-lock-card">
          <text class="pro-lock-title">VIP AI 解析</text>
          <text class="pro-lock-copy">根据你的 FIRE 数据生成约 500 字的重点解析</text>
          <text class="pro-lock-badge">会员专属功能</text>
          <button class="secondary pro-open" data-fire-press="true" @click="showProPrompt" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">开通 Pro 会员</button>
        </view>
        <view v-if="proNotice" class="pro-notice" role="status" aria-live="polite">
          <text>VIP AI 解析需要会员权限，开通后即可查看。</text>
          <button class="secondary" data-fire-press="true" @click="proNotice = false" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">知道了</button>
        </view>
        <view v-if="showDiagnosis && isProMember" class="diagnosis"><view v-if="aiDiagnosis" class="ai-diagnosis">{{ aiDiagnosis }}</view><view v-else class="ai-diagnosis loading">正在生成 AI 解析…</view></view>
      </template>
      <button class="secondary" data-fire-press="true" @click="goHome" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">返回首页</button>
      <text class="formula">固定收益和存入假设，不计税费与通胀。</text>
    </view>
  </view>
</template>

<script setup>
import { pageLayoutStyle } from '@/utils/page-layout.js'
import AppFeedback from '@/components/AppFeedback.vue'
import { useFeedbackPage } from '@/utils/feedback-page.js'
import { showDialog, showNotice, dismissFeedback } from '@/utils/feedback.js'
const feedbackOwnerId = useFeedbackPage({ handleBack: false })
import { computed, reactive, ref, onUnmounted } from 'vue'
import AnimatedNumber from '@/components/AnimatedNumber.vue'
import { onLoad, onShow, onHide, onUnload, onBackPress } from '@dcloudio/uni-app'
import { state, refreshFinance, persistNow, deleteGoalPlan } from '@/store/index.js'
import { FireEngine, GoalEngine, ReelCalendarParts, ReelParts, SaveAssetRecord, LocalDay } from '@/utils/engine.js'
import { validateFireForm, validateGoalForm, hasValidFinance, freedomResult, createFreedomPlan } from '@/utils/finance-plan.js'
import { isMembershipActive } from '@/utils/membership.js'
import { askBehaviorAI } from '@/utils/api-service.js'

import {accountId} from '@/utils/account-cache.js'
import { useSessionDraft } from '@/utils/session-drafts.js'
const fromAssetTask=ref(false)
const mode = ref('fire'), errors = ref([]), saving = ref(false), showDiagnosis = ref(false), proNotice = ref(false), aiDiagnosis = ref(''), aiLoading = ref(false)
const fire = reactive({assets:'',monthlyDeposit:'',retirementExpense:'',rate:'4',withdrawal:'4'})
const goal = reactive({name:'',assets:'',amount:'',monthlyDeposit:'',expectedMonths:'',rate:'4'})
const fireFields = [
  {key:'assets',label:'当前可投资资产',unit:'元',placeholder:'请输入当前资产，可填0'},
  {key:'monthlyDeposit',label:'每月存入金额',unit:'元/月',placeholder:'请输入每月存入，可填0'},
  {key:'retirementExpense',label:'退休后每月消费',unit:'元/月',placeholder:'请输入退休后每月消费'},
  {key:'rate',label:'预期年化收益率',unit:'%/年',placeholder:'请输入年化收益率，例如4'},
  {key:'withdrawal',label:'退休后年度提取率',unit:'%/年',placeholder:'请输入提取率，例如4'},
]
const goalFields = [
  {key:'assets',label:'为目标已准备的金额',unit:'元',placeholder:'请输入已准备金额，可填0'},
  {key:'amount',label:'目标金额',unit:'元',placeholder:'请输入目标金额'},
  {key:'monthlyDeposit',label:'每月存入金额',unit:'元/月',placeholder:'请输入每月存入，可填0'},
  {key:'expectedMonths',label:'期望多久达到',unit:'个月',placeholder:'请输入整数个月'},
  {key:'rate',label:'预期年化收益率',unit:'%/年',placeholder:'请输入年化收益率，例如4'},
]
const fireResult = ref(null), goalResult = ref(null), calculatedGoal = ref(null), now = ref(Date.now())
const configured = computed(() => hasValidFinance(state))
const result = computed(() => mode.value === 'fire' ? fireResult.value : goalResult.value)
const resultAssets = computed(() => mode.value === 'fire' ? state.finance.assets : calculatedGoal.value.assets)
const parts = computed(() => result.value && result.value.date ? ReelCalendarParts(result.value.date, now.value) : null)
const totalDays = computed(() => result.value && result.value.date ? ReelParts(result.value.date, now.value).days : null)
const countdownUnits = computed(() => parts.value ? [
  {id:'years',value:parts.value.years,label:'年'},{id:'months',value:parts.value.months,label:'个月'},
  {id:'days',value:parts.value.days,label:'天'},{id:'hours',value:parts.value.hours,label:'时'},
  {id:'minutes',value:parts.value.minutes,label:'分'},{id:'seconds',value:parts.value.seconds,label:'秒'},
] : [])
const coverage = computed(() => {
  const assets = Number(state.finance.assets), expense = Number(state.finance.retirementExpense), withdrawal = Number(state.finance.withdrawal)
  return Number.isFinite(assets) && Number.isFinite(expense) && expense > 0 && Number.isFinite(withdrawal)
    ? Math.min(100, Math.max(0, (assets * withdrawal / 100 / 12) / expense * 100)) : null
})
const depositRatio = computed(() => {
  const deposit = Number(state.finance.monthlyDeposit), expense = Number(state.finance.retirementExpense)
  return Number.isFinite(deposit) && expense > 0 ? deposit / expense * 100 : null
})
const conservative = computed(() => FireEngine({...state.finance,rate:Math.max(-50,state.finance.rate - 2)}))
const isProMember = computed(() => isMembershipActive(state))
const diagnosisSections = computed(() => {
  if (!isProMember.value || !fireResult.value) return []
  const r = fireResult.value
  const years = r.years === null ? '当前假设下100年内暂未达到' : r.years + ' 年'
  return [
    { title: '当前财务状态分析', body: '当前资产 ' + money(state.finance.assets) + ' 元，每月存入 ' + money(state.finance.monthlyDeposit) + ' 元；FIRE目标门槛为 ' + money(r.target) + ' 元。' },
    { title: '自由日距离分析', body: r.date ? '预计在 ' + dateText(r.date) + ' 达到目标，距离约 ' + years + '。当前进度为 ' + r.progress.toFixed(1) + '%。' : '当前假设下暂未在100年内达到目标，请先调整资产、每月存入或收益率。' },
    { title: '储蓄速度分析', body: '每月存入与退休后每月消费的比例为 ' + (depositRatio.value === null ? '暂无数据' : depositRatio.value.toFixed(1) + '%') + '；提高稳定存入金额会缩短计划周期。' },
    { title: '消费和提取率分析', body: '退休后每月消费为 ' + money(state.finance.retirementExpense) + ' 元，年度提取率为 ' + state.finance.withdrawal + '%；提取率越低，所需目标资产越高。' },
    { title: '风险提示', body: '这是基于固定收益率的长期模拟，不包含税费、通胀、市场波动和突发支出。请把结果当作规划基准，不当作收益承诺。' },
    { title: '优先行动建议', body: '先保持记账和每月存入记录，定期核对实际资产与计划差异；若进度偏离，再调整支出或收入结构。' },
    { title: '下一阶段计划', body: '建议每月复盘一次资产、存入金额和退休后消费假设，再决定是否更新自由日。' },
  ]
})
let timer = null, visible = false, navigating = false
function switchMode(next) { mode.value = next; errors.value = []; showDiagnosis.value = false; proNotice.value = false; now.value = Date.now() }
function invalidate(which) {
  errors.value = []
  proNotice.value = false
  if (which === 'fire') fireResult.value = null
  else { goalResult.value = null; calculatedGoal.value = null }
}
function toggleDiagnosis() {
  if (!isProMember.value) { showDiagnosis.value = true; proNotice.value = true; return }
  showDiagnosis.value = !showDiagnosis.value; proNotice.value = false
  if (showDiagnosis.value && !aiDiagnosis.value) generateDiagnosis()
}
async function generateDiagnosis() {
  if (aiLoading.value || !fireResult.value) return
  aiLoading.value = true; aiDiagnosis.value = ''
  const r = fireResult.value
  const question = '请根据我的 FIRE 退休倒计时和财务数据，生成一段约500字以内的 VIP 专属解析。只讲结论、关键问题和下一步行动，不讲空泛背景，不绕弯。请说明目标资产门槛、预计退休时间、当前进度、每月存入对结果的影响、最需要优先调整的一到三件事，并明确风险。不要承诺收益，不要编造数据。'
  try {
    const result = await askBehaviorAI({ question, finance: state.finance, countdown: r.date ? '预计退休日期：'+dateText(r.date)+'；剩余约'+(r.years == null ? '100年以上或暂不可达' : r.years+'年') : '当前计划暂不可达', personality: state.personalityTests || {} })
    const answer = result && (result.reply || result.message || result.content)
    if (!answer) throw new Error('AI 没有返回解析')
    aiDiagnosis.value = String(answer).replace(/\*\*/g,'').trim().slice(0,1200)
  } catch (error) {
    aiDiagnosis.value = 'AI 解析暂时失败：' + (error.message || '请稍后重试')
  } finally { aiLoading.value = false }
}
function showProPrompt() { uni.navigateTo({ url: '/pages/profile/membership?upgrade=1' }) }
function money(value) { return Number(value).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2}) }
function dateText(date) { const d = new Date(date); return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日' }
function stopClock() { if (timer !== null) clearInterval(timer); timer = null }
function startClock() {
  stopClock()
  if (!visible) return
  // #ifdef H5
  if (typeof document !== 'undefined' && document.hidden) return
  // #endif
  now.value = Date.now()
  timer = setInterval(() => { now.value = Date.now() }, 1000)
}
function handleVisibility() {
  // #ifdef H5
  if (document.hidden) stopClock(); else startClock()
  // #endif
}
function returnToTools() { uni.reLaunch({url:'/pages/tools/index',complete:()=>{navigating=false}}) }
function back() {
  if (navigating) return
  navigating = true
  const pages = getCurrentPages()
  if (pages.length > 1) uni.navigateBack({delta:1,fail:returnToTools,success:()=>{navigating=false}})
  else returnToTools()
}
function goHome() { uni.reLaunch({url:'/pages/index/index'}) }

async function calculate() {
  if (saving.value) return
  const parsed = mode.value === 'fire' ? validateFireForm(fire) : validateGoalForm(goal)
  errors.value = parsed.errors
  if (errors.value.length) return
  saving.value = true
  await new Promise(resolve => setTimeout(resolve, 650))
  if (mode.value === 'fire') {
    const oldFinance=state.finance,oldProfile=state.profile,oldPlan=state.freedomPlan,oldEntered=state.financeEntered
    const oldAssets=JSON.parse(JSON.stringify(state.assetHistory||[])),oldHero=JSON.parse(JSON.stringify(state.hero||null)),oldExp=state.exp
    try {
      state.finance={...state.finance,...parsed.finance}
      state.financeEntered=true
      const assetResult=SaveAssetRecord(state,{amount:String(parsed.finance.assets),date:LocalDay()},LocalDay(),false)
      if(!assetResult)throw new Error('资产记录无效，请检查金额')
      state.freedomPlan=createFreedomPlan(state.finance)
      if(!persistNow())throw new Error('保存失败，请检查设备存储后重试')
      fireResult.value=freedomResult(state)
      calculatorDraft.clear()
      showNotice({title:'自由计划已保存，经验将在云端确认后更新',icon:'none'})
      if(fromAssetTask.value)goHome()
    } catch(error) {
      state.finance=oldFinance;state.profile=oldProfile;state.financeEntered=oldEntered
      if(oldPlan===undefined)delete state.freedomPlan;else state.freedomPlan=oldPlan
      state.assetHistory=oldAssets;state.hero=oldHero;state.exp=oldExp
      errors.value=[error.message||'保存失败，请稍后重试']
    }
  } else {
    const old = state.goalDraft
    const plan = {...parsed.plan,calculatedAt:Date.now()}
    state.goalDraft = plan
    if (persistNow()) {
      calculatorDraft.clear()
      calculatedGoal.value = plan; goalResult.value = GoalEngine(plan)
      showNotice({title:'目标草稿已保存',icon:'none'})
    } else { state.goalDraft = old; errors.value = ['保存失败，请检查设备存储后重试'] }
  }
  now.value = Date.now()
  saving.value = false
}
function publishGoal(){
 if(!calculatedGoal.value||!goalResult.value||saving.value)return
 saving.value=true
 const old=state.goalPlan,oldHome=state.homeCountdown
 state.goalPlan={...calculatedGoal.value,id:old?.id||'goal-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),reviewedAt:Date.now(),rewardVersion:1,progress:goalResult.value.progress,targetDate:goalResult.value.date?dateText(goalResult.value.date):'100年内暂未可达'}
 state.homeCountdown='goal'
 if(persistNow()){calculatorDraft.clear();showNotice({title:'目标已保存到首页，经验将在云端确认后更新',icon:'none'});goHome()}
 else{state.goalPlan=old;state.homeCountdown=oldHome;errors.value=['保存失败，请重试']}
 saving.value=false
}
async function removeGoal(){
 if(saving.value||!state.goalPlan)return
 saving.value=true
 const uid=accountId(),id=String(state.goalPlan.id||state.goalPlan.name)
 try{
  const result=await showDialog({title:'删除这个目标？',content:'删除后无法恢复。首页将切回自由日，资产记录和自由日计划会保留。',confirmText:'删除目标',danger:true})
  if(!result.confirm||uid!==accountId()||id!==String(state.goalPlan?.id||state.goalPlan?.name))return
  if(!deleteGoalPlan()){errors.value=['保存失败，目标仍已保留，请重试'];return}
  calculatorDraft.clear();goalResult.value=null;calculatedGoal.value=null;showNotice({title:'目标已删除',icon:'none'});goHome()
 }finally{saving.value=false}
}
onLoad(options => {
  refreshFinance()
  fromAssetTask.value=options?.task==='assets'
  mode.value = options && options.mode === 'goal' ? 'goal' : 'fire'
  if (configured.value) {
    for (const key of ['assets','monthlyDeposit','retirementExpense','rate','withdrawal']) fire[key] = String(state.finance[key])
    fireResult.value = freedomResult(state)
  }
  const saved = options?.from==='home' ? state.goalPlan : state.goalDraft || state.goalPlan
  if (saved) {
    for (const key of Object.keys(goal)) goal[key] = saved[key] == null ? '' : String(saved[key])
    const parsed = validateGoalForm(goal)
    if (!parsed.errors.length) {
      calculatedGoal.value = {...saved,...parsed.plan}
      goalResult.value = GoalEngine(calculatedGoal.value)
    }
  }
  // #ifdef H5
  if (typeof document !== 'undefined') document.addEventListener('visibilitychange',handleVisibility)
  if (typeof window !== 'undefined') { window.addEventListener('pageshow',startClock); window.addEventListener('pagehide',stopClock) }
  // #endif
})
onShow(() => { visible = true; startClock() })
onHide(() => { visible = false; stopClock() })
function cleanup() {
  visible = false
  stopClock()
  // #ifdef H5
  if (typeof document !== 'undefined') document.removeEventListener('visibilitychange',handleVisibility)
  if (typeof window !== 'undefined') { window.removeEventListener('pageshow',startClock); window.removeEventListener('pagehide',stopClock) }
  // #endif
}
onUnload(cleanup)
onUnmounted(cleanup)
onBackPress(event => {
  if (dismissFeedback(feedbackOwnerId)) return true
  if (event && event.from === 'navigateBack') return false
  if (getCurrentPages().length > 1) return false
  back()
  return true
})
const calculatorDraft=useSessionDraft(()=>({mode:mode.value,fire:{...fire},goal:{...goal}}),draft=>{
 if(draft?.mode==='fire'||draft?.mode==='goal')mode.value=draft.mode
 for(const [target,saved] of [[fire,draft?.fire],[goal,draft?.goal]])for(const key of Object.keys(target))if(typeof saved?.[key]==='string')target[key]=saved[key]
})
</script>

<style lang="scss" scoped>
.calculation-loading{position:fixed;inset:0;z-index:1000;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(243,244,242,.94);backdrop-filter:blur(8px)}.loading-spinner{width:42px;height:42px;border:3px solid #dce8dc;border-top-color:#315f4a;border-radius:50%;animation:calculator-spin .8s linear infinite}.loading-title{margin-top:18px;color:#243830;font-size:18px;font-weight:600}.loading-copy{margin-top:8px;color:#7b8b7e;font-size:13px}@keyframes calculator-spin{to{transform:rotate(360deg)}}
.calculator-page { min-height:100vh; box-sizing:border-box; padding:calc(24px + var(--fire-status-top, env(safe-area-inset-top))) 24px calc(32px + env(safe-area-inset-bottom)); background:#f3f4f2; color:#243830; }
.page-head { display:flex; align-items:center; gap:12px; margin-bottom:24px; }
.back,.head-space { width:44px; min-height:44px; flex-shrink:0; }
.back { display:flex; align-items:center; justify-content:center; padding:0; border:0; background:transparent; color:#173d35; font-size:30px; font-weight:600; }
.page-title { flex:1; font-size:18px; font-weight:600; }
.intro-title,.intro-sub,.empty-hint,.formula,.result-label,.result-sub,.unreachable { display:block; }
.intro-title { font-size:25px; font-weight:700; color:#173d35; }
.intro-sub { color:#71807a; font-size:13px; line-height:1.8; margin-top:8px; }
.mode-tabs { display:flex; gap:4px; padding:4px; margin:24px 0 16px; border-radius:12px; background:#e7ede5; }
button { min-height:44px; min-width:44px; display:flex; align-items:center; justify-content:center; line-height:1.4; font-size:14px; border-radius:10px; border:0; transition:transform 180ms ease,opacity 180ms ease; }
button::after { border:0; }
button:active { transform:scale(.98); }
button[disabled] { opacity:.5; }
.mode-tabs button { flex:1; margin:0; padding:8px 4px; background:transparent; color:#71807a; font-size:13px; }
.mode-tabs .active { background:#fff; color:#173d35; font-weight:600; box-shadow:0 1px 3px rgba(23,61,53,.04); }
.empty-hint { margin:12px 0; color:#71807a; font-size:13px; line-height:1.8; }
.form-panel,.result-panel { background:#fff; border:1px solid #e7eee7; border-radius:16px; padding:20px 16px; }
.form-row + .form-row { margin-top:18px; }
.form-row label { display:block; font-size:14px; margin-bottom:8px; }
.input-row { display:flex; align-items:center; gap:8px; padding:10px 12px; min-height:44px; box-sizing:border-box; background:#fafbf8; border:1px solid #dde7dd; border-radius:10px; }
.input-row:focus-within { border-color:#4f8068; }
.input-row input { flex:1; min-width:0; height:28px; font-size:16px; color:#173d35; pointer-events:auto; }
.unit { flex-shrink:0; color:#71807a; font-size:12px; }
.formula { margin-top:14px; color:#71807a; font-size:12px; line-height:1.8; }
.primary,.secondary { width:100%; margin:18px 0 0; padding:12px 16px; }
.primary { background:#173d35; color:#fff; }
.secondary { background:#eef2e8; color:#173d35; }
.error-panel { margin-top:16px; padding:12px; background:#fff2ed; color:#995147; border-radius:10px; }
.error-panel text { display:block; font-size:13px; line-height:1.8; }
.result-panel { margin-top:24px; }
.result-label { font-size:18px; font-weight:600; }
.countdown-line { display:flex; flex-wrap:wrap; gap:8px 12px; margin:20px 0 12px; }
.countdown-unit { display:flex; align-items:baseline; gap:3px; }
.countdown-number { display:inline-block; min-width:2ch; font-size:24px; font-weight:600; font-variant-numeric:tabular-nums; }
.countdown-label { font-size:12px; color:#71807a; }
.result-sub,.unreachable { font-size:13px; line-height:1.8; color:#71807a; }
.progress { margin:20px 0 8px; height:6px; border-radius:6px; background:#dfe8db; overflow:hidden; }
.progress-fill { height:100%; border-radius:6px; background:#527059; }
.result-row { display:flex; justify-content:space-between; gap:12px; padding:10px 0; font-size:13px; line-height:1.7; }
.result-row text:last-child { text-align:right; }
.diagnosis { margin-top:14px; border-top:1px solid #e7eee7; }.ai-diagnosis{padding:16px 0;color:#426052;font-size:14px;line-height:1.9;white-space:pre-wrap}.ai-diagnosis.loading{color:#71807a}
.pro-lock-card,.pro-notice { margin-top:14px; padding:16px; border:1px solid #dce7db; border-radius:12px; background:#f2f7ef; }
.pro-lock-title { display:block; color:#173d35; font-size:16px; font-weight:700; }
.pro-lock-copy,.pro-lock-badge { display:block; margin-top:7px; color:#71807a; font-size:13px; line-height:1.6; }
.pro-lock-badge { color:#527059; font-weight:600; }
.pro-open { margin-top:12px; }
.pro-notice text { display:block; color:#52605a; font-size:13px; line-height:1.7; }
.pro-notice button { margin-top:10px; }
.diagnosis-section { padding:14px 0; border-bottom:1px solid #e7eee7; }
.diagnosis-title { display:block; color:#173d35; font-size:15px; font-weight:700; }
.diagnosis-copy { display:block; margin-top:6px; color:#52605a; font-size:13px; line-height:1.8; }
@media (prefers-reduced-motion:reduce) { button { transition:none; } button:active { transform:none; } .countdown-number { animation:none; } }

/* Shared status-bar inset and 12px content gap; keep bottom navigation fixed. */
 .fire-page-calculator-index{padding-top:var(--fire-page-top)}
.delete-goal{padding:8px 10px;color:#a35d4e;background:#faf0ea;font-size:12px;min-height:40px}
</style>
