<template>
  <view class="tools-view fire-page-tools-index" :style="pageLayoutStyle" :class="{ 'page-entry-reset': pageEntryReset }">
    <AppFeedback :owner-id="feedbackOwnerId" />
    <view class="fire-tab-content" :class="{ 'tab-content-reset':pageEntryReset, 'tab-content-slide':!pageEntryReset }" :style="tabEntryStyle">

    <view class="tools-head">
      <text class="tools-h1">工具</text>
      <text class="tools-sub">规划、行动、消费，都从这里开始</text>
    </view>

    <view class="tool-controls">
      <view class="tool-search"><text class="search-icon">⌕</text><input v-model="query" placeholder="搜索工具" placeholder-class="search-placeholder" confirm-type="search" /></view>
      <view class="category-list" aria-label="工具分类">
        <view v-for="category in categories" :key="category" class="category-chip" data-fire-press="true" :class="{ active: activeCategory === category }" @tap="activeCategory = category" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{ category }}</view>
      </view>
    </view>

    <text v-if="commonTools.length" class="group-title">常用功能</text>
    <view v-if="commonTools.length" class="tool-grid">
      <view v-for="t in commonTools" :key="t.route" class="tool-card" data-fire-press="true" @tap="goTool(t)" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">
        <view class="tool-icon" :style="{ background: t.bg }">
          <text v-if="t.icon === 'ai'" class="tool-text-icon">AI</text><text v-else-if="t.icon === 'music'" class="tool-text-icon music-text-icon">♪</text><image v-else class="tool-icon-img" :src="iconUri(t.icon, t.color)" mode="aspectFit" />
        </view>
        <view class="tool-text">
          <view class="tool-name-row"><text class="tool-name">{{ t.name }}</text><text v-if="t.status" class="tool-status" :class="{ 'tool-status-development': t.status === '开发中' }">{{ t.status }}</text></view>
          <text class="tool-desc">{{ t.desc }}</text>
        </view>
        <text class="tool-arrow">›</text>
      </view>
    </view>

    <text v-if="uncommonTools.length" class="group-title second">更多工具</text>
    <view v-if="uncommonTools.length" class="tool-grid">
      <view v-for="t in uncommonTools" :key="t.route" class="tool-card" data-fire-press="true" @tap="goTool(t)" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">
        <view class="tool-icon" :style="{ background: t.bg }">
          <text v-if="t.icon === 'ai'" class="tool-text-icon">AI</text><text v-else-if="t.icon === 'music'" class="tool-text-icon music-text-icon">♪</text><image v-else class="tool-icon-img" :src="iconUri(t.icon, t.color)" mode="aspectFit" />
        </view>
        <view class="tool-text">
          <view class="tool-name-row"><text class="tool-name">{{ t.name }}</text><text v-if="t.status" class="tool-status" :class="{ 'tool-status-development': t.status === '开发中' }">{{ t.status }}</text></view>
          <text class="tool-desc">{{ t.desc }}</text>
        </view>
        <text class="tool-arrow">›</text>
      </view>
    </view>

    <view v-if="!commonTools.length && !uncommonTools.length" class="tools-empty">没有找到匹配的工具</view>
    <text class="safe-note">更多工具正在开发</text>
    </view>
    <BottomTabs ref="bottomNav" current="tools" />
  </view>
</template>

<script>
import { pageEntryMixin } from '@/utils/page-entry.js'
import AppFeedback from '@/components/AppFeedback.vue'
import { feedbackPageMixin } from '@/utils/feedback-page.js'
import { showNotice, dismissFeedback } from '@/utils/feedback.js'
import BottomTabs from '@/components/BottomTabs.vue'
import { state, persist } from '@/store/index.js'
import { LocalDay } from '@/utils/engine.js'

const ICONS = {
  calculator: 'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM8 7h8M8 11h.5M12 11h.5M16 11h.5M8 15h.5M12 15h.5M16 15h.5M8 19h8',
  curve: 'M3 18c4-1 5-7 9-5s4 5 9-9M3 21h18',
  hero: 'M12 3l2.4 5 5.6.8-4 3.9.9 5.5-4.9-2.6-4.9 2.6.9-5.5-4-3.9 5.6-.8L12 3z',
  wishlist: 'M7 7V5a5 5 0 0 1 10 0v2M3 7h18v14H3zM8 14l3 3 5-5',
  ledger: 'M5 3h14v18l-3-2-4 2-4-2-3 2zM8 7h8M8 11h8M8 15h5',
  books: 'M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5zM4 5.5v16M8 7h8M8 11h8',
  time: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
  ai: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8 12h8M12 8v8',
  music: 'M9 18V5l10-2v13M9 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6M19 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6',
}

const TOOL_CATALOG = [
  { route: 'calculator', category: '财务', url: '/pages/calculator/index', icon: 'calculator', color: '#426052', bg: '#edf2e9', name: '躺平倒计时', desc: '计算你的自由日' },
  { route: 'savings-curve', category: '财务', url: '/pages/savings-curve/index', icon: 'curve', color: '#426052', bg: '#edf2e9', name: '人生模拟曲线', desc: '用选择题看见存款变化', status: '测试中' },
  { route: 'ledger', category: '财务', url: '/pages/ledger/index', icon: 'ledger', color: '#426052', bg: '#edf2e9', name: '记账', desc: '轻松记下每笔消费' },
  { route: 'wishlist', category: '生活', url: '/pages/wishlist/index', icon: 'wishlist', color: '#426052', bg: '#edf2e9', name: '极简拔草清单', desc: '给心动一点时间', status: '测试中' },
  { route: 'hero', category: '成长', url: '/pages/hero/index', icon: 'hero', color: '#426052', bg: '#edf2e9', name: 'FIRE 英雄传', desc: '每日行动与成长' },
  { route: 'personality', category: '成长', url: '/pages/personality/index', icon: 'hero', color: '#426052', bg: '#edf2e9', name: '人格测试', desc: '大五人格或 MBTI', status: '测试中' },
  { route: 'reading-library', category: '成长', url: '', icon: 'books', color: '#426052', bg: '#edf2e9', name: '认知数据库', desc: '打开阅读内容', status: '开发中' },
  { route: 'time-ledger', category: '效率', url: '', icon: 'time', color: '#426052', bg: '#edf2e9', name: '时间复利计算器', desc: '算清你的生命时薪', status: '待开发' },
  { route: 'ai', category: '效率', url: '/pages/ai/index', icon: 'ai', color: '#426052', bg: '#edf2e9', name: '行为建议 AI', desc: '询问消费与习惯建议' },
  { route: 'music', category: '内容', url: '/pages/music/index', icon: 'music', color: '#426052', bg: '#edf2e9', name: '音乐', desc: '选择专注氛围', status: '' },
]

function svgUri(svg) {
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg)
}

export default {
  mixins: [feedbackPageMixin, pageEntryMixin],
  onBackPress() { return dismissFeedback(this.feedbackOwnerId) },
  components: { AppFeedback,  BottomTabs },
  data() { return { state, query: '', activeCategory: '全部' } },
  computed: {
    sortedTools() {
      const usage = state.toolUsage || {}
      return TOOL_CATALOG.map(function (t, i) {
        const u = usage[t.route] || {}
        const score = (Number(u.clicks) || 0) + (Number(u.visits) || 0)
        return { tool: t, score, index: i }
      }).sort(function (a, b) {
        if (a.tool.route === 'calculator') return -1
        if (b.tool.route === 'calculator') return 1
        if (b.score !== a.score) return b.score - a.score
        return a.index - b.index
      }).map(function (x) { return x.tool })
    },
    categories() {
      return ['全部'].concat(Array.from(new Set(TOOL_CATALOG.map(function (tool) { return tool.category }))))
    },
    filteredTools() {
      const query = String(this.query || '').trim().toLowerCase()
      return this.sortedTools.filter(function (tool) {
        const categoryMatch = this.activeCategory === '全部' || tool.category === this.activeCategory
        const textMatch = !query || (tool.name + ' ' + tool.desc).toLowerCase().includes(query)
        return categoryMatch && textMatch
      }, this)
    },
    commonTools() { return this.filteredTools.slice(0, 4) },
    uncommonTools() { return this.filteredTools.slice(4) },
  },
  onShow() { uni.hideTabBar({ animation: false }) },
  methods: {
    iconUri(key, color) {
      const p = ICONS[key] || ICONS.ledger
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${p}"/></svg>`
      return svgUri(svg)
    },
    goTool(t) {
      if (!state.toolUsage) state.toolUsage = {}
      const u = state.toolUsage[t.route] || { clicks: 0, visits: 0 }
      u.clicks = (Number(u.clicks) || 0) + 1
      u.lastUsed = Date.now()
      state.toolUsage[t.route] = u
      persist()
      if (t.url) {
        let target = t.url
        if (t.route === 'ledger') {
          const month = LocalDay().slice(0, 7)
          const budget = (state.monthlyTargets && state.monthlyTargets[month]) || {}
          if (Number.isSafeInteger(budget.expense) && budget.expense > 0 && Number.isSafeInteger(budget.income) && budget.income > 0) target = '/pages/ledger/edit'
        }
        uni.navigateTo({ url: target })
      } else showNotice({ title: t.name + ' 开发中', icon: 'none' })
    },
  },
}
</script>

<style>
@import '../../utils/tab-content.css';
@keyframes toolPageIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes toolSlideIn { from { opacity: 0; transform: translateX(18px); } to { opacity: 1; transform: translateX(0); } }
.tools-view { min-height: 100vh; padding: calc(24px + var(--fire-status-top, env(safe-area-inset-top))) 20px calc(88px + env(safe-area-inset-bottom)); background: #f3f4f2; box-sizing: border-box;  }
.tool-card { animation: toolSlideIn .48s cubic-bezier(.22,1,.36,1) backwards; }
.tool-card:nth-child(2) { animation-delay: .06s; }.tool-card:nth-child(3) { animation-delay: .12s; }.tool-card:nth-child(4) { animation-delay: .18s; }.tool-card:nth-child(5) { animation-delay: .24s; }.tool-card:nth-child(6) { animation-delay: .3s; }
.tool-controls{margin:18px 0 24px}.tool-search{height:44px;display:flex;align-items:center;gap:8px;padding:0 13px;background:#fff;border:1px solid #dfe7dd;border-radius:13px;box-sizing:border-box}.search-icon{font-size:22px;color:#527059;line-height:1}.tool-search input{flex:1;height:42px;color:#243830;font-size:14px;background:transparent}.search-placeholder{color:#9aa99d}.category-list{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;width:100%;box-sizing:border-box}.category-chip{display:flex;align-items:center;justify-content:center;min-width:58px;height:36px;padding:0 14px;border-radius:999px;background:#e5eee4;color:#71807a;font-size:12px;white-space:nowrap;box-sizing:border-box;touch-action:manipulation}.category-chip:active{transform:scale(.97)}.category-chip.active{background:#315f4a;color:#fff;font-weight:600}.tools-empty{padding:54px 16px;text-align:center;color:#71807a;font-size:14px}
.tools-head { margin-bottom: 20px; }
.tools-h1 { display: block; font-size: 24px; font-weight: 700; color: #143e37; letter-spacing: 0.5px; }
.tools-sub { display: block; font-size: 13px; color: #71807a; margin-top: 8px; }
.group-title { display: block; font-size: 13px; color: #71807a; margin-bottom: 12px; }
.group-title.second { margin-top: 28px; }
.tool-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.tool-card {
  position: relative;
  min-height: 104px;
  padding: 12px 10px;
  background: #ffffff;
  border-radius: 17px;
  border: 1px solid #e9ece7;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 11px;
  box-sizing: border-box;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.tool-card:active { transform: scale(0.97); }
.tool-icon { width: 28px; height: 28px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.tool-icon-img { width: 19px; height: 19px; }.tool-text-icon { color: #426052; font-size: 16px; font-weight: 700; letter-spacing: -.04em; }.music-text-icon { font-size: 24px; font-weight: 400; }
.tool-name-row{display:flex;align-items:center;gap:6px;min-width:0}.tool-status{padding:2px 5px;border-radius:5px;background:#fff4d8;color:#9a6b21;font-size:9px;white-space:nowrap}.tool-text { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
.tool-status-development{background:transparent;color:#c4433d;flex-shrink:0;font-weight:500}
.tool-name { min-width: 0; display: block; font-size: 14px; font-weight: 500; color: #243830; line-height: 1.4; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.tool-desc { display: block; font-size: 11px; color: #71807a; line-height: 1.5; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.tool-arrow { position: absolute; right: 12px; top: 17px; font-size: 18px; color: #8c998f; line-height: 1; }
.safe-note { display: block; text-align: center; font-size: 11px; color: #8b9489; margin-top: 40px; }
@media screen and (max-width:390px){.tools-view{padding:calc(18px + var(--fire-status-top, env(safe-area-inset-top))) 16px calc(78px + env(safe-area-inset-bottom))}.tools-head{margin-bottom:16px}.tools-h1{font-size:24px}.tool-controls{margin:14px 0 18px}.tool-search{height:40px}.category-chip{height:32px;min-width:52px;padding:0 10px}.tool-grid{gap:8px}.tool-card{min-height:96px;padding:10px 9px;gap:8px;border-radius:13px}.tool-icon{width:26px;height:26px;border-radius:8px}.tool-icon-img{width:17px;height:17px}.tool-name{font-size:12px}.tool-desc{font-size:10px}.tool-arrow{right:9px;top:13px;font-size:16px}.group-title.second{margin-top:20px}}
/* Reset only entry animations; page nodes and scroll position stay intact. */
.tools-view.page-entry-reset{animation:none}
.tools-view.page-entry-reset .tool-card{animation:none}

/* Shared status-bar inset and 12px content gap; keep bottom navigation fixed. */
 .fire-page-tools-index{padding-top:var(--fire-page-top)}
</style>