<template>
  <view class="add-page fire-page-wishlist-add" :style="pageLayoutStyle">
    <AppFeedback :owner-id="feedbackOwnerId" />
    <view class="add-head"><view class="back" data-fire-press="true" @tap="back" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">‹</view><text class="title">添加消费计划</text><view class="head-space"></view></view>
    <scroll-view class="form-scroll" scroll-y>
      <view class="form-content">
        <text class="label">名称</text>
        <input class="field-input" v-model="form.name" type="text" placeholder="请输入消费计划名称" placeholder-class="placeholder" />
        <text class="label">预计金额</text>
        <input class="field-input" v-model="form.amount" type="digit" placeholder="请输入预计金额" placeholder-class="placeholder" />
        <text class="label">分类</text>
        <view class="choices"><view v-for="cat in categories" :key="cat.id" class="choice" data-fire-press="true" :class="{active:form.category===cat.id}" @tap="form.category=cat.id" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{cat.name}}</view></view>
        <text class="label">冷静期</text>
        <view class="choices"><view v-for="d in [3,7,30]" :key="d" class="choice" data-fire-press="true" :class="{active:form.days===d}" @tap="form.days=d" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{d}} 天</view></view>
        <text v-if="error" class="error">{{error}}</text>
      </view>
    </scroll-view>
    <view class="submit-bar"><button class="submit fire-button-primary fire-button-lg" data-fire-press="true" type="button" @click="handleSubmit" :disabled="saving" hover-class="fire-pressed" :hover-start-time="0" :hover-stay-time="90" :hover-stop-propagation="true">{{saving?'保存中…':'完成'}}</button></view>
  </view>
</template>
<script setup>
import { useSessionDraft } from '@/utils/session-drafts.js'
import { pageLayoutStyle } from '@/utils/page-layout.js'
import AppFeedback from '@/components/AppFeedback.vue'
import { useFeedbackPage } from '@/utils/feedback-page.js'
import { showNotice } from '@/utils/feedback.js'
const feedbackOwnerId = useFeedbackPage()
import { reactive, ref } from 'vue'
import { state, persistNow } from '@/store/index.js'
import {createWishlist} from '@/utils/wishlist.js'
const form=reactive({name:'',amount:'',category:'other',days:7})
const error=ref(''),saving=ref(false)
const categories=[{id:'shopping',name:'购物'},{id:'food',name:'饮食'},{id:'travel',name:'旅行'},{id:'life',name:'生活'},{id:'other',name:'其他'}]
function back(){uni.navigateBack()}
function handleSubmit(){
 if(saving.value)return
 saving.value=true;error.value=''
 const result=createWishlist(state,form,persistNow)
 if(!result){saving.value=false;error.value='请检查名称、金额和冷静期，并确认设备存储可用';showNotice({title:error.value,icon:'none'});return}
 formDraft.clear();showNotice({title:'消费计划已添加',icon:'success'})
 uni.navigateBack({fail:()=>uni.redirectTo({url:'/pages/wishlist/index',fail:()=>showNotice({title:'计划已保存，请返回列表查看',icon:'none'})})})
}
const formDraft=useSessionDraft(()=>({...form}),draft=>{for(const key of Object.keys(form))if(key in (draft||{}))form[key]=draft[key]})
</script>
<style lang="scss">
.add-page{position:fixed;inset:0;background:#f8f9f5;color:#173d35;display:flex;flex-direction:column;box-sizing:border-box;padding-top:var(--fire-status-top, env(safe-area-inset-top));padding-bottom:env(safe-area-inset-bottom);overflow:hidden}
.add-head{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;flex-shrink:0;border-bottom:1px solid #e1e7de}.back{width:44px;height:44px;display:flex;align-items:center;justify-content:center;font-size:32px}.title{font-size:20px;font-weight:600}.head-space{width:44px}
.form-scroll{flex:1;height:0;min-height:0;width:100%;pointer-events:auto}.form-content{padding:8px 24px calc(112px + env(safe-area-inset-bottom));box-sizing:border-box}.label{display:block;margin-top:22px;color:#737e76;font-size:13px}.field-input{display:block;width:100%;height:54px;margin-top:10px;padding:0 16px;border:1px solid #e1e7de;border-radius:13px;background:#fff;box-sizing:border-box;color:#173d35;font-size:16px;pointer-events:auto}.field-input:focus{border-color:#4f8068;outline:none}.placeholder{color:#a2afa5}.choices{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}.choice{min-width:58px;min-height:44px;padding:0 16px;display:flex;align-items:center;justify-content:center;border-radius:11px;background:#edf0e9;color:#737e76;font-size:13px;box-sizing:border-box}.choice.active{background:#e5eee4;color:#173d35;font-weight:600}.error{display:block;margin-top:18px;color:#a35d4e;font-size:13px}.submit-bar{position:relative;z-index:20;flex-shrink:0;padding:12px 24px calc(16px + env(safe-area-inset-bottom));background:#f8f9f5;border-top:1px solid #e1e7de;pointer-events:auto}.submit{position:relative;z-index:21;width:100%;min-height:50px;margin:0;border-radius:13px;background:#173d35;color:#fff;display:flex;align-items:center;justify-content:center;font-size:16px;pointer-events:auto}.submit:active{transform:scale(.98)}.submit:after{border:0}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}

/* Shared status-bar inset and 12px content gap; keep bottom navigation fixed. */
 .fire-page-wishlist-add{padding-top:var(--fire-page-top)}
</style>